var newRulesCount = 0;

function applyUiMod()
{
	jQuery(".button").button();
	jQuery(".chkbox").button();
	jQuery(".typeselect").multiselect({
		   create: function(){
			   var idTarget = "#" + jQuery(this).attr("id") + "_Types";
			   var curValues = jQuery(idTarget).val();
			   var aCurValues = curValues.split(",");
			   
			   jQuery(this).multiselect("uncheckAll");
			   //TODO : dirty : implement an hash here
			   jQuery(this).multiselect("widget").find(":checkbox").each(function(){
				   for(i=0;i < aCurValues.length;i++)
				   {
					   if (aCurValues[i] == jQuery(this).val())
					   {
						   jQuery(this).click();
					   }
				   }   
			   });
		   },
		   close: function()
		   {
			   var aCheckedValues = jQuery(this).multiselect("getChecked").map(function(){
				   return this.value;	
			   }).get();
			   var idTarget = "#" + jQuery(this).attr("id") + "_Types";
			   jQuery(idTarget).val(aCheckedValues);
			   
		   },
		   selectedList: 2
	});
}

jQuery(document).ready(function(){
	
	applyUiMod();
		
	jQuery(".addItemRule").live("click", function(e){
		e.preventDefault();
		
		var currentId = jQuery(this).parent().attr("id");
		currentId = currentId.substring("addItemRuleTargetId".length);
		var targetId = "#addItemRuleTargetId" + currentId;
		var idParent = jQuery(this).attr("id");
		var selectedType = jQuery("#addItemRuleSelectTypeId" + currentId + " :selected").attr("id");
		jQuery(targetId).append("<li class=\"ruleItem\" id=\"itemnew" + newRulesCount + "\"></li>");
		jQuery(targetId + " > li:last").append().load("plugins/PortalMapper/jsp/itemRule.jsp?ruleType="+selectedType+"&ruleCount="+newRulesCount+"&idParent="+idParent, function(){
			applyUiMod();
		});
		newRulesCount += 1;
	});
	
	jQuery(".addGroupRule").live("click", function(e){
		e.preventDefault();
		jQuery(".button").button();
		var targetId = jQuery(this).parent().attr("id");
		var idParent = jQuery(this).attr("id");
		jQuery("#" + targetId).append("<li class=\"groupRuleItem\" id=\"itemnew" + newRulesCount + "\"></li>");
		jQuery("#" + targetId + " > li:last").append().load("plugins/PortalMapper/jsp/groupRule.jsp?ruleCount="+newRulesCount+"&idParentPortal="+idParent, function(){
			applyUiMod();
		});
		newRulesCount += 1;
	});
	
	jQuery(".addPortalRule").live("click", function(e){
		e.preventDefault();
		var targetId = "#addPortalRuleTargetId";
		jQuery(targetId).append("<li class=\"portalRuleItem\" id=\"itemnew" + newRulesCount + "\"></li>");
		jQuery(targetId + " > li:last").append().load("plugins/PortalMapper/jsp/portalRule.jsp?ruleCount="+newRulesCount, function(){
			applyUiMod();
		});
		newRulesCount += 1;
	});
	
	jQuery(".deleteItem").live("click", function(e){
		e.preventDefault();
		var ids = jQuery(this).attr("id");
		
		var arrayIds = ids.split("|");
		var id = arrayIds[0];
		var parentId = arrayIds[1];
		if(jQuery("#ruleId_" + id).hasClass("itemRule"))
		{
			//TODO is get right ?
			jQuery.get("plugins/PortalMapper/jsp/ajax/ajaxRemoveRule.jsp?id=" + id + "&parentId=" + parentId, function(data){
				if(data == "ok")
				{
					jQuery("#item" + id).remove();
				}
			});
		}
		else
		{
			jQuery("#item" + id).remove();
		}
		//jQuery(this).parent().remove();
	});
	
	//save admin page
	jQuery(".saveLinkId").click(function(e){
		e.preventDefault();
		
		var ruleItems = "";
		//iterate over class .itemRule : each one defines a rule (type + N inputParams)
		var formvals = {};
		
		//iterate over new items
		jQuery(".newItemRule").each(function(){
			var ruleId = jQuery(this).val();
			var paramClassName = "inputParam_" + ruleId;
			
			//each paramClassName is an input containing rule definitions
			//build a key/value array (input name -> value) and post
			jQuery.each(jQuery('.' + paramClassName),function(i, obj){
			    if (formvals[obj.name] == undefined)
			    {
			    	if (obj.type == "checkbox")
			    	{
			    		formvals[obj.name] = jQuery(this).is(":checked");
			    	}
			    	else
		    		{
			    		formvals[obj.name] = obj.value;
		    		}
			    }
			    else if (typeof formvals[obj.name] == Array)
			    {
			    	formvals[obj.name].push(obj.value);
			    }
			    else
			    {
			    	formvals[obj.name] = [formvals[obj.name],obj.value];
			    }
			});
			
		})

		//iterate over existing elements : identify elements to update
		jQuery(".itemRule").each(function(){
			var ruleId = jQuery(this).val();
			var paramClassName = ".inputParam_" + ruleId;
			var paramSaveClassName = ".inputParam_" + ruleId + "Save";
		
			jQuery(paramSaveClassName).each(function(i, obj){
				var curInputId = "#" + obj.name.substring(4);
				var curInputSaveId = "#" + obj.name;
				var curInputVal = jQuery(curInputId).val();
				var curInputSaveVal = jQuery(curInputSaveId).val();
				
				//alert(curInputId + " " + jQuery(curInputId).attr('type'));
				if (jQuery(curInputId).attr('type') == "checkbox")
		    	{
					curInputVal = jQuery(curInputId).is(":checked");
					curInputSaveVal = jQuery(curInputSaveId).val() == "true" ? true : false;
					//alert(curInputId + " " + curInputVal);
					//alert(curInputSaveId + " " + curInputSaveVal);
		    	}
				
				if(curInputVal != curInputSaveVal)
				{
					//alert("diff " + ruleId);
					
					jQuery.each(jQuery(paramClassName),function(i, obj){
					    if (formvals[obj.name] == undefined)
					    {
					    	//   	alert("name " + formvals[obj.name]);
					    	if (obj.type == "checkbox")
					    	{
					    		//alert("chk " + formvals[obj.name]);
					    		formvals[obj.name] = jQuery(this).is(":checked");
					    	}
					    	else
				    		{
					    		formvals[obj.name] = obj.value;
				    		}
					    }
					    else if (typeof formvals[obj.name] == Array)
					    {
					    	formvals[obj.name].push(obj.value);
					    }
					    else
					    {
					    	formvals[obj.name] = [formvals[obj.name],obj.value];
					    }
					});
					
					
					//end
				}
			});
		});
		
		jQuery.post("plugins/PortalMapper/jsp/ajax/ajaxAddRule.jsp", formvals, function(data){
		//TODO protect
			location.reload();
		});
		
	});
	
	jQuery(".rwLabel").live("click", function(e){
		e.preventDefault();
		var inputId = "#" + jQuery(this).attr("id").substring(4);
		jQuery(this).hide();
		jQuery(inputId).show();
		jQuery(inputId).focus();
	});
	
	jQuery(".rwInput").live("blur", function(e){
		e.preventDefault();
		var labelId = "#read" + jQuery(this).attr("id");
		jQuery(this).hide();
		jQuery(labelId).html(jQuery(this).val());
		jQuery(labelId).show();
	});
});