$("idSearchDataByIdSubmit").observe("click", function(data)
{
	var id = $("idSearchDataById").getValue();
	data.preventDefault();
	
	var parameters = {"id" : id};
	JCMS.window.Modal.showJSP("plugins/SearchById/jsp/ajaxFindById.jsp", null, parameters);
});
