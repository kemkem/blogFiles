#!/usr/bin/perl
my $stateFile = $ARGV[0];

open(STATE_IN, "<$stateFile");

foreach $line (<STATE_IN>)
{
  chomp($line);
  my ($inode, $size, $permissions, $uid, $gid, $file) = split(':', $line, 6);
  if( -f $file || -d $file)
  {
    #add inode / size check here if desired
    chmod(oct($permissions), $file);
    chown($uid, $gid, $file);
  }
}

close(STATE_IN);
