#!/bin/sh

scriptsRoot="[CHANGEME]"
backupRoot="[CHANGEME]"
snapshotRoot="/var/cache/rsnapshot"

echo "backup started" > $scriptsRoot/.mailtmp
date >> $scriptsRoot/.mailtmp
du -sh $backupRoot/* >> $scriptsRoot/.mailtmp

$scriptsRoot/syncFromRemote.sh [USER] [HOST] $snapshotRoot $backupRoot

echo "backup done" >> $scriptsRoot/.mailtmp
date >> $scriptsRoot/.mailtmp
du -sh $backupRoot/* >> $scriptsRoot/.mailtmp

mail user@domain.com -s "backup log" < $scriptsRoot/.mailtmp

