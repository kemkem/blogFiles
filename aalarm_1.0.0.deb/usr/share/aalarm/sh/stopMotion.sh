#!/bin/sh

#/etc/init.d/motion stop
service motion stop
