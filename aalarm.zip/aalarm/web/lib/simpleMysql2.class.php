<?php


class simpleMysql
{
	var $_dbCnx;
	var $_results;
	var $_cur;
	var $_nbRows = 0;
	var $_error;
	var $_debug = false;
	
	#
	# connect
	#
	function connect($host, $database, $username, $password)
	{
		if (!$this->_dbCnx = mysql_connect($host,$username,$password))
		{
			return -1;
		}
		if (!mysql_select_db($database, $this->_dbCnx))
		{
			$this->_error = mysql_error();
			return -1;
		}
		return 0;
	}

	#
	# close connection
	#
	function close()
	{
		mysql_close();
	}
	
	#
	# exec
	#
	function exec($req)
	{
		if ($this->_results = mysql_query($req))
		{
			return mysql_affected_rows();
		}
		else
		{
			if ($this->_debug)
			{
				$this->printDebug($req);
			}
			return -1;
		}
	}
	
	#
	# select
	#
	function select($req)
	{
		if ($this->_debug == 2)
		{
			$this->printDebug($req);
		}
		if (!$this->_results = mysql_query($req))
		{
			if ($this->_debug)
			{
				$this->printDebug($req);
			}
			return -1;
		}
		$this->_nbRows = mysql_num_rows($this->_results);
		return $this->_nbRows;
	}
	
	#
	# getNbRows
	#
	function getNbRows()
	{
		return $this->_nbRows;
	}

	#
	# fetchCell
	# 
	function fetchCell()
	{
		if ($line = mysql_fetch_row($this->_results))
		{
			return $line[0];
		}
		else
		{
			return null;
		}
	}
	
	#
	# fetchLineObject
	# 
	function fetchLineObject()
	{
		if($cur = mysql_fetch_object($this->_results))
		{
			return $cur;
		}
		else
		{
			return null;
		}
	}

	#
	# fetchLineArray
	#
	function fetchLineArray()
	{
		$tab = Array();
		if($tab = mysql_fetch_row($this->_results))
		{
			return $tab;
		}
		else
		{
			return null;
		}
	}
	
	#
	# fetchColArray
	#
	function fetchColArray()
	{
		$tab = Array();
		if ($this->getNbRows())
		{
			while ($line = mysql_fetch_row($this->_results))
			{
				$tab[] = $line[0];
			}
			return $tab;
		}
		else
		{
			return null;
		}
	}
	
	#
	# fetchKeyValueArray
	#
	function fetchKeyValueArray()
	{
		$tab = Array();
		if ($this->getNbRows())
		{
			while ($line = mysql_fetch_row($this->_results))
			{
				$tab[] = Array($line[0], $line[1]);
			}
			return $tab;
		}
		else
		{
			return null;
		}
	}
		
	#
	# fetchKeyValueAssoc
	#
	function fetchKeyValueAssoc()
	{
		$tab = Array();
		if ($this->getNbRows())
		{
			while ($line = mysql_fetch_row($this->_results))
			{
				$tab[$line[0]] = $line[1];
			}
			return $tab;
		}
		else
		{
			return null;
		}
	}
	
	#
	# fetchLinesArray
	#
	function fetchLinesArray()
	{
		$tab = Array();
		if ($this->getNbRows())
		{
			while ($line = mysql_fetch_array($this->_results))
			{
				$tab[] = $line;
			}
			return $tab;
		}
		else
		{
			return null;
		}
	}
	
	#
	# fetchLinesObjects
	#
	function fetchLinesObjects()
	{
		$tab = Array();
		if ($this->getNbRows())
		{
			while ($cur = mysql_fetch_object($this->_results))
			{
				$tab[] = $cur;
			}
			return $tab;
		}
		else
		{
			return null;
		}
	}
	
	#
	# fetchLinesAssoc
	#
	function fetchLinesAssoc()
	{
		$tab = Array();
		if ($this->getNbRows())
		{
			while ($line = mysql_fetch_assoc($this->_results))
			{
				$tab[] = $line;
			}
			return $tab;
		}
		else
		{
			return null;
		}
	}
	
	#
	# selectCell
	#
	function selectCell($req)
	{
		$this->select($req);
		return $this->fetchCell();
	}
	
	#
	# selectLineObject
	#
	function selectLineObject($req)
	{
		$this->select($req);
		return $this->fetchLineObject();
	}

	#
	# selectLineArray
	#
	function selectLineArray($req)
	{
		$this->select($req);
		return $this->fetchLineArray();
	}
	
	#
	# selectColArray
	#
	function selectColArray($req)
	{
		$this->select($req);
		return $this->fetchColArray();
	}
	
	#
	# selectKeyValueArray
	#
	function selectKeyValueArray($req)
	{
		$this->select($req);
		return $this->fetchKeyValueArray();
	}
		
	#
	# selectKeyValueAssoc
	#
	function selectKeyValueAssoc($req)
	{
		$this->select($req);
		return $this->fetchKeyValueAssoc();
	}
	
	#
	# selectLinesArray
	#
	function selectLinesArray($req)
	{
		$this->select($req);
		return $this->fetchLinesArray();
	}

	#
	# selectLinesObjects
	#
	function selectLinesObjects($req)
	{
		$this->select($req);
		return $this->fetchLinesObjects();
	}
	
	#
	# selectLinesAssoc
	#
	function selectLinesAssoc($req)
	{
		$this->select($req);
		return $this->fetchLinesAssoc();
	}
	
	#
	# getGrammar
	#
	function getGrammar($singular, $plural, $none)
	{
		$nbRows = $this->getNbRows();
		if ($nbRows > 1)
		{
			$plural = str_replace("<NUM>", $nbRows, $plural);
			return $plural;
		}
		else if ($nbRows == 1)
		{
			return $singular;
		}
		else
		{
			return $none;
		}
	}
	
	#
	# setDebug
	#
	function setDebug($debug)
	{
        	$this->_debug = $debug;
	}
    
	#
	# printDebug
	#
	function printDebug($req)
	{
		if ($this->_debug == 2)
		{
			print "<BR />Request \"".$req."\"<BR />";
		}
		else if ($debug == 1)
		{
			print "<BR />[".mysql_errno()."] ".mysql_error()."<BR />Request was \"".$req."\"<BR />";
		}
	}
	
}
?>