<?php
require 'lib/simpleMysql2.class.php';

$username="aalarm";
$password="pwd";
$database="aalarm";

$db = new simpleMysql();
$db->connect("localhost", $database, $username, $password);
?>
