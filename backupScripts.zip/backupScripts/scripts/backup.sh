#!/bin/sh

scriptsRoot="[CHANGEME]"
snapshotRoot="/var/cache/rsnapshot"

if [ $# -ne 1 ];then
	echo "Not enough arguments"
	echo "./backup.sh [rsnapshot period]"
	exit
fi

if [ -f $scriptsRoot/state ];then
	$scriptsRoot/restoreState.pl $scriptsRoot/state
fi

/usr/bin/rsnapshot $1

$scriptsRoot/saveState.pl $snapshotRoot > $scriptsRoot/state

/bin/cp $scriptsRoot/state $snapshotRoot

/bin/chown -R snapshot:snapshot $snapshotRoot
/bin/chmod -R 700 $snapshotRoot/*

