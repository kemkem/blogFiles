#!/usr/bin/perl
my $tree = $ARGV[0];

foreach $file (`/usr/bin/find ${tree}`)
{
  chomp($file);
  (undef, $inode, $mode, undef, $uid, $gid, $undef, $size, undef, undef, undef, undef, undef) = stat($file);
  $permissions = $mode & 07777;
  printf "%i:%i:%04o:%i:%i:%s\n", $inode, $size, $permissions, $uid, $gid, $file;
}

