#!/bin/sh

if [ $# -ne 4 ];then
	echo "Not enough arguments"
	echo "./syncFromRemote [user host remoteDir backupDir]"
	exit
fi

remoteUser=$1
remoteHost=$2
remoteDir=$3
backupDir=$4

if [ -d $4/$2 ];then
	mkdir $4/$2
fi

rsync -avzH -e ssh $1@$2:$3 $4/$2 

